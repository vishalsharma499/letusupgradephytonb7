str1 = "Prakhar"
str2 = "Mishra"

# Finding length of string.
print("Length of str1: ",len(str1),"\nLenght of str2: ",len(str2))

# Concatinate 2 strings.
print("After concatinating str1 and str2: ",str1 + " " + str2)

# Counting no occurance of sub-string in string.
print("'a' in string 1 occurs ",str1.count('a')," times")

# To check weather the string consist of alphabets only or not.
print("String 1 consist of alphabets only: ",str1.isalpha())

# Converting whole string to upper case.
str3 = "jai mata dii"
print("String 3 before conversion to upper case: ",str3)
print("String 3 after conversion to upper case: ",str3.upper())
