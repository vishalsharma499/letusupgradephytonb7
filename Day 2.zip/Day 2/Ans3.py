st = {1,2,3,5,6,7,8}

# Printing set st.
print("our set st is: ",st)

# Printing type of st.
print("Type of st: ",type(st))

# Adding element to set st and getting it in a sorted form.
st.add(4)
print("after adding 4 to st: ",st)

# Removing element from set.
st.remove(7)
print("Set st after removel of 7: ",st)

# Checking if the element exist in set st or not.
print("3 exist in st: ",3 in st)

# printing of lenght of a set st.
print("Lenght if set st: ",len(st))
