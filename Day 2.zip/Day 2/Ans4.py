tup = (8,4,6,2,9,6,1,5)

# Length of a tuple tup.
print("Lenght of tup: ",len(tup))

# Type of tup.
print("Type of tup: ",type(tup))

# Maximum element in tuple tup.
print("Maximum element in tuple tup: ",max(tup))

# Minimum element in tup.
print("Minimum elememt in tuple tup: ",min(tup))

# Converting any sequence to tuple.
seq = "Prakhar"
seq = tuple(seq)
print("Type of seq is: ",type(seq))
print("seq is: ",seq)
