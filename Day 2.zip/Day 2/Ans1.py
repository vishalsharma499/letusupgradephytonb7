# list and its default functions 
lst = [1,2,3,4,5]
# 1: length of a list
print("lenght: ",len(lst))
# maximum element in a list
print("Max element: ",max(lst))
# minimum element in a list
print("Min element: ",min(lst))
# 4: remove element in a list
lst.remove(3)
print("List after removel: ",lst)
# 5: inserting an element at desired index
lst.insert(2,3)
print("List after inserting: ",lst)
# 3 is inserted at index 2 and 4 and 5 is moved forward at index 3 and 4 respectively.
