dit = {1:'prakhar',2:'prabhat',3:'shiva'}

# length of dictionary
print("Length of dictionary: ",len(dit))

# finding type of dictionary.
print("type of dictionary : ",type(dit))

#printing the keys of dictionary dit.
print(dit.keys())

# converting dictionary to string.
print("type of dictionary : ",type(str(dit))," converted to string")

# copying 1 dictionary to another
dit2 = dit.copy()
print("dictionary 2 is: ",dit2)
