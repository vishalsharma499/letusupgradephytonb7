alt = input("enter altitude: ")
alt = int(alt)
if alt<=1000:
    print("Lant the plane.")
elif alt>1000 and alt<=5000:
    print("Bring it further down to 1000ft.")
else:
    print("Turn around and attempt later.")
