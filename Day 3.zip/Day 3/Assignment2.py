print("Prime no. from 1 to 200 are: ")
count = 0
for i in range(1,201):
    count=0
    for j in range(1,i+1):
        if i%j==0:
            count+=1
    if count == 2:
        print(i)
